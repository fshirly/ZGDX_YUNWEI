CREATE FUNCTION getChildLst_moduleRest(rootId VARCHAR(1000))
  RETURNS VARCHAR(20000)
  BEGIN

    DECLARE sTemp VARCHAR(21000);

    DECLARE sTempChd VARCHAR(20000);

    SET sTemp = '$';

    SET sTempChd = cast(rootId as CHAR);

    WHILE sTempChd is not null DO

      SET sTemp = concat(sTemp, ',', sTempChd);

      SELECT group_concat(id) INTO sTempChd FROM (select t.id, t.pid from FBS_MODULE t union all (select s.id, s.MODULE_ID pid from FBS_METHOD s)) v where FIND_IN_SET(pid, sTempChd) > 0;

    END WHILE;

    RETURN sTemp;

  END;
