CREATE PROCEDURE getTableSequence(IN tableName VARCHAR(128), IN rowcount INT, OUT uid INT)
  BEGIN
    DECLARE tempobjID DECIMAL(15,0);
    SET tempobjID =0;
    START TRANSACTION;
    SELECT GenValue INTO tempobjID FROM SysKeyGenerator WHERE GenName = tableName FOR UPDATE ;
    IF tempobjID > 0 THEN
      UPDATE SysKeyGenerator SET GenValue = GenValue + rowcount WHERE GenName = tableName;
      SET tempobjID = tempobjID + 1;
    ELSE
      SET tempobjID = 10000;
      INSERT INTO SysKeyGenerator (GenName,GenValue) VALUES (tableName, tempobjID + rowcount);
    END IF;

    SET uid = tempobjID;
    COMMIT;
  END;
