CREATE FUNCTION nextval(seq_name VARCHAR(50))
  RETURNS INT
  BEGIN
    DECLARE is_exist_name  VARCHAR(50);
    DECLARE VALUE INTEGER;
    SELECT GenName INTO is_exist_name FROM SysKeyGenerator WHERE GenName = seq_name;
    IF ISNULL(is_exist_name)THEN INSERT INTO SysKeyGenerator VALUES(seq_name,1);
    ELSE UPDATE SysKeyGenerator SET GenValue = GenValue + 1 WHERE GenName = seq_name;
    END IF;
    SET VALUE = (SELECT GenValue FROM SysKeyGenerator WHERE GenName = seq_name);
    RETURN VALUE;
  END;
