CREATE FUNCTION getChildLst(rootId INT)
  RETURNS VARCHAR(1000)
  BEGIN
    DECLARE sTemp VARCHAR(1000);
    DECLARE sTempChd VARCHAR(1000);

    SET sTemp = '$';
    SET sTempChd =CAST(rootId AS CHAR);

    WHILE sTempChd IS NOT NULL DO
      SET sTemp = CONCAT(sTemp,',',sTempChd);
      SELECT GROUP_CONCAT(MenuID) INTO sTempChd FROM SysMenuModule WHERE FIND_IN_SET(ParentMenuID,sTempChd)>0;
    END WHILE;
    RETURN sTemp;
  END;
