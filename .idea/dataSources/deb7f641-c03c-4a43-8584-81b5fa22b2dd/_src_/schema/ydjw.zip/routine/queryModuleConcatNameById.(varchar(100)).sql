CREATE FUNCTION queryModuleConcatNameById(moduleId VARCHAR(100))
  RETURNS VARCHAR(10000)
  BEGIN


    DECLARE sParentList VARCHAR(10000);
    DECLARE sParentTemp VARCHAR(10000);

    DECLARE sParentNameList VARCHAR(10000);
    DECLARE sParentNameTemp VARCHAR(10000);

    -- 根据岗位ID查询出机构ID
    SELECT name into sParentNameTemp FROM FBS_MODULE where id = moduleId;

    SET sParentTemp =moduleId;


    WHILE sParentTemp IS NOT NULL DO
      IF (sParentList IS NOT NULL) THEN
        SET sParentList = CONCAT(sParentTemp,',',sParentList);
        IF (sParentNameList IS NOT NULL AND sParentNameList != '') THEN
          SET sParentNameList = CONCAT(sParentNameTemp,'-',sParentNameList);
        ELSE
          SET sParentNameList = CONCAT(sParentNameTemp);
        END IF;
      ELSE
        SET sParentList = CONCAT(sParentTemp);
        SET sParentNameList = CONCAT('');
      END IF;

      SELECT GROUP_CONCAT(pid) ,GROUP_CONCAT(name) INTO sParentTemp , sParentNameTemp FROM FBS_MODULE WHERE FIND_IN_SET(id,sParentTemp)>0;
    END WHILE;
    RETURN sParentNameList;
  END;
