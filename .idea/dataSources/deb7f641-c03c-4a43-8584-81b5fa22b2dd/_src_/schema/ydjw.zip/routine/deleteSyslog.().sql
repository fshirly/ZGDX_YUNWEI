CREATE PROCEDURE deleteSyslog()
  BEGIN
    delete from SyslogUserLoginLog where TO_DAYS(NOW()) - TO_DAYS(collectTime)>365;
    delete from SyslogClientLoginLog where  TO_DAYS(NOW()) - TO_DAYS(collectTime)>365;
    delete from SyslogClientIllegalEvent where  TO_DAYS(NOW()) - TO_DAYS(collectTime)>2;
    delete from SyslogVpnAccessLog WHERE TO_DAYS(NOW()) - TO_DAYS(collectTime)>2;
    delete FROM SyslogProxyAccessLog WHERE TO_DAYS(NOW()) - TO_DAYS(collectTime)>2;
    delete from SyslogXitOperatorInfo WHERE TO_DAYS(NOW()) - TO_DAYS(collectTime)>2;
    /** select * from syslogxitoperatorinfo where  TO_DAYS(NOW()) - TO_DAYS(collectTime)<2;**/
  END;
