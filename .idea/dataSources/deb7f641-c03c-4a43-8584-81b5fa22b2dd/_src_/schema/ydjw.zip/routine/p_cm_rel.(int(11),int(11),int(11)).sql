CREATE PROCEDURE p_cm_rel(IN sciId INT, IN p_ciTypeId INT, IN p_relTypeId INT)
  BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE v_icon TEXT;
    DECLARE v_relId INT;
    DECLARE v_ciId INT;
    DECLARE v_table VARCHAR(50);
    DECLARE v_key VARCHAR(50);
    DECLARE v_name VARCHAR(50);
    DECLARE v_targetTypeName VARCHAR(50);
    DECLARE v_typename VARCHAR(50);
    DECLARE v_reltypeId INT;
    DECLARE stmt LONGTEXT DEFAULT '';
    DECLARE c CURSOR FOR
      SELECT rd.ResTypeName,IF(rd.Icon IS NOT NULL,rd.Icon,"") AS icon,rc.CiRelationshipId, rc.TargetCiId AS ciId,IF(rd.pageUrl IS NOT NULL,rd.TableName,'ResCi') AS TableName,
                            IF(rd.PrimaryKeyColumn IS NOT NULL,rd.PrimaryKeyColumn,'CiId') AS PrimaryKeyColumn,
                            IF(rd.nameColumn IS NOT NULL,rd.nameColumn,'Name') AS nameColumn,
        rrt.RelationshipTypeName,rrt.RelationshipTypeId
      FROM ResCiRelationship rc
        LEFT JOIN ResRelationship rr ON rr.Relationshipid = rc.RelationshipId
        LEFT JOIN ResTypeDefine rd ON rd.ResTypeID = rr.TargetTypeId
        LEFT JOIN ResRelationShipType rrt ON rrt.RelationshipTypeId = rr.RelationshiptypeId
      WHERE rc.SourceCiId = sciId
            AND IF(p_ciTypeId = -1,1=1,rr.TargetTypeId=p_ciTypeId) AND IF(p_relTypeId = -1,1=1,rrt.RelationshipTypeId=p_relTypeId)
      UNION
      SELECT rd.ResTypeName,IF(rd.Icon IS NOT NULL,rd.Icon,"") AS icon,rc.CiRelationshipId, rc.SourceCiId AS ciId,IF(rd.pageUrl IS NOT NULL,rd.TableName,'ResCi') AS TableName,
                            IF(rd.PrimaryKeyColumn IS NOT NULL,rd.PrimaryKeyColumn,'CiId') AS PrimaryKeyColumn,
                            IF(rd.nameColumn IS NOT NULL,rd.nameColumn,'Name') AS nameColumn,
        rrt.ReverseName,rrt.RelationshipTypeId
      FROM ResCiRelationship rc
        LEFT JOIN ResRelationship rr ON rr.Relationshipid = rc.RelationshipId
        LEFT JOIN ResTypeDefine rd ON rd.ResTypeID = rr.SourceTypeId
        LEFT JOIN ResRelationShipType rrt ON rrt.RelationshipTypeId = rr.RelationshiptypeId
      WHERE rc.TargetCiId = sciId
            AND IF(p_ciTypeId = -1,1=1,rr.SourceTypeId=p_ciTypeId) AND IF(p_relTypeId = -1,1=1,rrt.RelationshipTypeId=p_relTypeId);
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1;

    OPEN c;
    REPEAT
      IF(done <> 1) THEN
        FETCH FROM c INTO v_targetTypeName,v_icon,v_relId,v_ciId,v_table,v_key,v_name,v_typename,v_reltypeId;
        SET stmt = CONCAT(stmt,'select ','"',v_targetTypeName,'"',' as ciTypeName',',','"',v_icon,'"',' as icon',',',v_name,' as ciName',',',v_relId,' as relId ',',',v_ciId,' as targetId ',',','"',v_typename,'"',' as relName ',',',v_reltypeId,' as relTypeId',' from ',v_table,' where ',v_key,'=',v_ciId);
        SET stmt = CONCAT(stmt,' union ');
      END IF;
    UNTIL done
    END REPEAT;
    CLOSE c;
    IF stmt IS NOT NULL THEN
      SET @stmt = CONCAT(stmt,' select "" as ciTypeName,"" as icon,rc.Name as ciName,rc.CiId as relId,rc.CiId as targetId,rc.CiId as relTypeId,rc.Name as relName from ResCi rc where rc.CiId = -1 ');
      PREPARE stmt FROM @stmt;
      EXECUTE stmt;
    ELSE

      SELECT "" AS ciTypeName,"" AS icon,rc.Name AS ciName,rc.CiId AS relId,rc.CiId AS targetId,rc.CiId AS relTypeId,rc.Name AS relName FROM ResCi rc WHERE rc.CiId = -1;
    END IF;
  END;
