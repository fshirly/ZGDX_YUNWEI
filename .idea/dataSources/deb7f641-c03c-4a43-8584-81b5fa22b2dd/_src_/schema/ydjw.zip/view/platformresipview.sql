CREATE VIEW platformresipview AS
  SELECT
    `ydjw`.`resprefixdevicebalancing`.`CiId`         AS `ciId`,
    `ydjw`.`resprefixdevicebalancing`.`COL_deviceip` AS `ip`
  FROM `ydjw`.`resprefixdevicebalancing`
  UNION SELECT
          `ydjw`.`resprefixcomputer`.`CiId`         AS `ciId`,
          `ydjw`.`resprefixcomputer`.`COL_deviceip` AS `ip`
        FROM `ydjw`.`resprefixcomputer`
  UNION SELECT
          `ydjw`.`resprefixnetworkdevice`.`CiId`         AS `ciId`,
          `ydjw`.`resprefixnetworkdevice`.`COL_deviceip` AS `ip`
        FROM `ydjw`.`resprefixnetworkdevice`
  UNION SELECT
          `ydjw`.`resprefixsafetyequipment`.`CiId`         AS `ciId`,
          `ydjw`.`resprefixsafetyequipment`.`COL_deviceip` AS `ip`
        FROM `ydjw`.`resprefixsafetyequipment`;
