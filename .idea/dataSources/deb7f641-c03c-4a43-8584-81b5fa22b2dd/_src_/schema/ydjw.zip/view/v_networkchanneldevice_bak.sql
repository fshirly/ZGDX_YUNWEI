CREATE VIEW v_networkchanneldevice_bak AS
  SELECT
    `network`.`CiId`                AS `CiId`,
    `network`.`COL_ApplicationType` AS `ApplicationType`,
    `network`.`COL_Area`            AS `Area`,
    `network`.`COL_network`         AS `NetWork`,
    `device`.`MOID`                 AS `MOID`,
    `device`.`MOName`               AS `MOName`,
    `device`.`MOAlias`              AS `MOAlias`
  FROM (`ydjw`.`resprefixnetworkdevice` `network`
    JOIN `ydjw`.`modevice` `device` ON ((`network`.`CiId` = `device`.`ResID`)))
  WHERE ((`network`.`COL_ApplicationType` IS NOT NULL) OR (`network`.`COL_Area` IS NOT NULL) OR
         (`network`.`COL_network` IS NOT NULL));
