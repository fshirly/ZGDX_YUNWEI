CREATE VIEW room_view AS
  SELECT
    `ydjw`.`resci`.`CiId` AS `CiId`,
    `ydjw`.`resci`.`Name` AS `Name`
  FROM `ydjw`.`resci`
  WHERE (`ydjw`.`resci`.`CiTypeid` = (SELECT `ydjw`.`restypedefine`.`ResTypeID`
                                      FROM `ydjw`.`restypedefine`
                                      WHERE (`ydjw`.`restypedefine`.`TableName` = 'ResPrefixRoom')));
