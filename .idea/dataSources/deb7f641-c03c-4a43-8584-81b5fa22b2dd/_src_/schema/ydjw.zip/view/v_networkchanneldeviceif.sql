CREATE VIEW v_networkchanneldeviceif AS
  SELECT
    `netinfo`.`Instance`         AS `Instance`,
    `netinfo`.`MOAlias`          AS `MOAlias`,
    `netinfo`.`MOName`           AS `MOName`,
    `netinfo`.`MOID`             AS `MOID`,
    `netinfo`.`DeviceMOID`       AS `DeviceMOID`,
    `v_device`.`MOName`          AS `DeviceMOName`,
    `v_device`.`MOAlias`         AS `DeviceMOAlias`,
    `v_device`.`ApplicationType` AS `ApplicationType`,
    `v_device`.`Area`            AS `Area`,
    `v_device`.`NetWork`         AS `NetWork`,
    `component`.`CiId`           AS `DeviceCiId`,
    `info`.`CiId`                AS `CiId`
  FROM (((`ydjw`.`rescicomponent` `component`
    JOIN `ydjw`.`resprefixslotinfo` `info` ON ((`component`.`ComponentId` = `info`.`CiId`))) JOIN
    `ydjw`.`v_networkchanneldevice` `v_device` ON ((`component`.`CiId` = `v_device`.`CiId`))) JOIN
    `ydjw`.`monetworkif` `netinfo` ON ((`netinfo`.`DeviceMOID` = `v_device`.`MOID`)))
  WHERE ((`info`.`COL_instance` = `netinfo`.`Instance`) AND (`info`.`COL_FlowTag` = 10));
