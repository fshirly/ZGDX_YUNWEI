CREATE VIEW mobject AS
  SELECT
    `ydjw`.`modevice`.`MOID`       AS `MOID`,
    `ydjw`.`modevice`.`MOName`     AS `MOName`,
    `ydjw`.`modevice`.`MOAlias`    AS `MOAlias`,
    `ydjw`.`modevice`.`OperStatus` AS `OperStatus`,
    `ydjw`.`modevice`.`AlarmLevel` AS `AlarmLevel`,
    `ydjw`.`modevice`.`DomainID`   AS `DomainID`,
    `ydjw`.`modevice`.`MOClassID`  AS `MOClassID`,
    -(1)                           AS `SourceMOID`
  FROM `ydjw`.`modevice`
  UNION SELECT
          `ydjw`.`mocpus`.`MOID`       AS `MOID`,
          `ydjw`.`mocpus`.`MOName`     AS `MOName`,
          `ydjw`.`mocpus`.`MOAlias`    AS `MOAlias`,
          `ydjw`.`mocpus`.`OperStatus` AS `OperStatus`,
          `ydjw`.`mocpus`.`AlarmLevel` AS `AlarmLevel`,
          -(1)                         AS `DomainID`,
          12                           AS `MOClassID`,
          `ydjw`.`mocpus`.`DeviceMOID` AS `SourceMOID`
        FROM `ydjw`.`mocpus`
  UNION SELECT
          `ydjw`.`momemories`.`MOID`       AS `MOID`,
          `ydjw`.`momemories`.`MOName`     AS `MOName`,
          `ydjw`.`momemories`.`MOAlias`    AS `MOAlias`,
          `ydjw`.`momemories`.`OperStatus` AS `OperStatus`,
          `ydjw`.`momemories`.`AlarmLevel` AS `AlarmLevel`,
          -(1)                             AS `DomainID`,
          13                               AS `MOClassID`,
          `ydjw`.`momemories`.`DeviceMOID` AS `SourceMOID`
        FROM `ydjw`.`momemories`
  UNION SELECT
          `ydjw`.`monetworkif`.`MOID`       AS `MOID`,
          `ydjw`.`monetworkif`.`MOName`     AS `MOName`,
          `ydjw`.`monetworkif`.`MOAlias`    AS `MOAlias`,
          `ydjw`.`monetworkif`.`OperStatus` AS `OperStatus`,
          `ydjw`.`monetworkif`.`AlarmLevel` AS `AlarmLevel`,
          -(1)                              AS `DomainID`,
          10                                AS `MOClassID`,
          `ydjw`.`monetworkif`.`DeviceMOID` AS `SourceMOID`
        FROM `ydjw`.`monetworkif`
  UNION SELECT
          `commit`.`MOID`       AS `MOID`,
          `commit`.`MOName`     AS `MOName`,
          `commit`.`MOAlias`    AS `MOAlias`,
          `commit`.`OperStatus` AS `OperStatus`,
          `commit`.`AlarmLevel` AS `AlarmLevel`,
          -(1)                  AS `DomainID`,
          11                    AS `MOClassID`,
          `commit`.`DeviceMOID` AS `SourceMOID`
        FROM `ydjw`.`movolumes` `commit`;
