CREATE VIEW restypeview AS
  SELECT
    `ydjw`.`restypedefine`.`ResTypeID`        AS `ResTypeID`,
    `ydjw`.`restypedefine`.`ResTypeName`      AS `ResTypeName`,
    `ydjw`.`restypedefine`.`ResTypeAlias`     AS `ResTypeAlias`,
    `ydjw`.`restypedefine`.`ResTypeDescr`     AS `ResTypeDescr`,
    `ydjw`.`restypedefine`.`ParentTypeId`     AS `ParentTypeId`,
    `ydjw`.`restypedefine`.`CreateTime`       AS `CreateTime`,
    `ydjw`.`restypedefine`.`LastModifyTime`   AS `LastModifyTime`,
    `ydjw`.`restypedefine`.`Icon`             AS `Icon`,
    `ydjw`.`restypedefine`.`TableName`        AS `TableName`,
    `ydjw`.`restypedefine`.`IsDefault`        AS `IsDefault`,
    `ydjw`.`restypedefine`.`IsAsset`          AS `IsAsset`,
    `ydjw`.`restypedefine`.`AssetTypeId`      AS `AssetTypeId`,
    `ydjw`.`restypedefine`.`IsComponent`      AS `IsComponent`,
    `ydjw`.`restypedefine`.`ParentTypeIds`    AS `ParentTypeIds`,
    `ydjw`.`restypedefine`.`PrimaryKeyColumn` AS `PrimaryKeyColumn`,
    `ydjw`.`restypedefine`.`nameColumn`       AS `nameColumn`,
    `ydjw`.`restypedefine`.`pageUrl`          AS `pageUrl`,
    `ydjw`.`restypedefine`.`FormColumn`       AS `FormColumn`,
    `ydjw`.`restypedefine`.`ElementIcon`      AS `ElementIcon`,
    `ydjw`.`restypedefine`.`ModelApplyStatus` AS `ModelApplyStatus`,
    `ydjw`.`restypedefine`.`MoTypeId`         AS `MoTypeId`,
    `ydjw`.`restypedefine`.`IsMoType`         AS `IsMoType`,
    `ydjw`.`restypedefine`.`ShowOrder`        AS `ShowOrder`,
    `ydjw`.`restypedefine`.`WorkingGroupId`   AS `WorkingGroupId`,
    `ydjw`.`restypedefine`.`DefaultHandlerId` AS `DefaultHandlerId`
  FROM `ydjw`.`restypedefine`
  WHERE (`ydjw`.`restypedefine`.`ResTypeID` IN
         (11013, 6, 7, 8, 9, 42, 11014, 11015, 11016, 10, 11, 12, 60, 11010, 11011, 11012, 49, 50, 52, 53, 54, 11021, 11022));
