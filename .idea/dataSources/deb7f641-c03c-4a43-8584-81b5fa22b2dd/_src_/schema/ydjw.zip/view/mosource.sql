CREATE VIEW mosource AS
  SELECT
    `m`.`MOID`       AS `MOID`,
    `m`.`MOName`     AS `MOName`,
    `m`.`AlarmLevel` AS `AlarmLevel`,
    `m`.`MOClassID`  AS `MOClassID`,
    `m`.`DeviceIP`   AS `DeviceIP`,
    `m`.`DomainID`   AS `DomainID`
  FROM `ydjw`.`modevice` `m`
  UNION SELECT
          `mysqldb`.`MOID`       AS `MOID`,
          `mysqldb`.`ServerName` AS `MOName`,
          `db`.`AlarmLevel`      AS `AlarmLevel`,
          `db`.`MOClassID`       AS `MOClassID`,
          `mysqldb`.`IP`         AS `DeviceIP`,
          `db`.`DomainID`        AS `DomainID`
        FROM (`ydjw`.`momysqldbserver` `mysqldb` LEFT JOIN `ydjw`.`modbmsserver` `db`
            ON ((`db`.`MOID` = `mysqldb`.`DBMSMOID`)))
  UNION SELECT
          `oraclein`.`MOID`         AS `MOID`,
          `oraclein`.`InstanceName` AS `MOName`,
          `db`.`AlarmLevel`         AS `AlarmLevel`,
          `db`.`MOClassID`          AS `MOClassID`,
          `oraclein`.`IP`           AS `DeviceIP`,
          `db`.`DomainID`           AS `DomainID`
        FROM (`ydjw`.`mooracleinstance` `oraclein` LEFT JOIN `ydjw`.`modbmsserver` `db`
            ON ((`db`.`MOID` = `oraclein`.`DBMSMOID`)))
  UNION SELECT
          `oracledb`.`MOID`   AS `MOID`,
          `oracledb`.`DBName` AS `MOName`,
          `db`.`AlarmLevel`   AS `AlarmLevel`,
          `db`.`MOClassID`    AS `MOClassID`,
          `db`.`IP`           AS `DeviceIP`,
          `db`.`DomainID`     AS `DomainID`
        FROM (`ydjw`.`mooracledb` `oracledb` LEFT JOIN `ydjw`.`modbmsserver` `db`
            ON ((`db`.`MOID` = `oracledb`.`DBMSMOID`)))
  UNION SELECT
          `db2in`.`MOID`         AS `MOID`,
          `db2in`.`InstanceName` AS `MOName`,
          `db`.`AlarmLevel`      AS `AlarmLevel`,
          `db`.`MOClassID`       AS `MOClassID`,
          `db2in`.`IP`           AS `DeviceIP`,
          `db`.`DomainID`        AS `DomainID`
        FROM
          (`ydjw`.`modb2instance` `db2in` LEFT JOIN `ydjw`.`modbmsserver` `db` ON ((`db`.`MOID` = `db2in`.`DBMSMOID`)))
  UNION SELECT
          `db2database`.`MOID`         AS `MOID`,
          `db2database`.`DatabaseName` AS `MOName`,
          `db`.`AlarmLevel`            AS `AlarmLevel`,
          `db`.`MOClassID`             AS `MOClassID`,
          `db`.`IP`                    AS `DeviceIP`,
          `db`.`DomainID`              AS `DomainID`
        FROM ((`ydjw`.`modb2database` `db2database` LEFT JOIN `ydjw`.`modb2instance` `db2in`
            ON ((`db2database`.`InstanceMOID` = `db2in`.`MOID`))) LEFT JOIN `ydjw`.`modbmsserver` `db`
            ON ((`db`.`MOID` = `db2in`.`DBMSMOID`)))
  UNION SELECT
          `mssql`.`MOID`       AS `MOID`,
          `mssql`.`ServerName` AS `MOName`,
          `db`.`AlarmLevel`    AS `AlarmLevel`,
          `db`.`MOClassID`     AS `MOClassID`,
          `mssql`.`IP`         AS `DeviceIP`,
          `db`.`DomainID`      AS `DomainID`
        FROM
          (`ydjw`.`momssqlserver` `mssql` LEFT JOIN `ydjw`.`modbmsserver` `db` ON ((`db`.`MOID` = `mssql`.`DBMSMOID`)))
  UNION SELECT
          `sybase`.`MOID`       AS `MOID`,
          `sybase`.`ServerName` AS `MOName`,
          `db`.`AlarmLevel`     AS `AlarmLevel`,
          `db`.`MOClassID`      AS `MOClassID`,
          `sybase`.`IP`         AS `DeviceIP`,
          `db`.`DomainID`       AS `DomainID`
        FROM (`ydjw`.`mosybaseserver` `sybase` LEFT JOIN `ydjw`.`modbmsserver` `db`
            ON ((`db`.`MOID` = `sybase`.`DBMSMOID`)))
  UNION SELECT
          `middle`.`MOID`       AS `MOID`,
          `middle`.`ServerName` AS `MOName`,
          `middle`.`AlarmLevel` AS `AlarmLevel`,
          `middle`.`MOClassID`  AS `MOClassID`,
          `middle`.`IP`         AS `DeviceIP`,
          `middle`.`DomainID`   AS `DomainID`
        FROM `ydjw`.`momiddlewarejmx` `middle`
  UNION SELECT
          `tcp`.`MOID`       AS `MOID`,
          `tcp`.`SiteName`   AS `MOName`,
          `tcp`.`AlarmLevel` AS `AlarmLevel`,
          `site`.`MOClassID` AS `MOClassID`,
          `tcp`.`IPAddr`     AS `DeviceIP`,
          `site`.`DomainID`  AS `DomainID`
        FROM (`ydjw`.`mositeport` `tcp` LEFT JOIN `ydjw`.`mowebsite` `site` ON ((`site`.`MOID` = `tcp`.`ParentMOID`)))
  UNION SELECT
          `dns`.`MOID`       AS `MOID`,
          `dns`.`SiteName`   AS `MOName`,
          `dns`.`AlarmLevel` AS `AlarmLevel`,
          `site`.`MOClassID` AS `MOClassID`,
          `dns`.`IPAddr`     AS `DeviceIP`,
          `site`.`DomainID`  AS `DomainID`
        FROM (`ydjw`.`mositedns` `dns` LEFT JOIN `ydjw`.`mowebsite` `site` ON ((`site`.`MOID` = `dns`.`ParentMOID`)))
  UNION SELECT
          `ftp`.`MOID`       AS `MOID`,
          `ftp`.`SiteName`   AS `MOName`,
          `ftp`.`AlarmLevel` AS `AlarmLevel`,
          `site`.`MOClassID` AS `MOClassID`,
          `ftp`.`IPAddr`     AS `DeviceIP`,
          `site`.`DomainID`  AS `DomainID`
        FROM (`ydjw`.`mositeftp` `ftp` LEFT JOIN `ydjw`.`mowebsite` `site` ON ((`site`.`MOID` = `ftp`.`ParentMOID`)))
  UNION SELECT
          `http`.`MOID`       AS `MOID`,
          `http`.`SiteName`   AS `MOName`,
          `http`.`AlarmLevel` AS `AlarmLevel`,
          `site`.`MOClassID`  AS `MOClassID`,
          `http`.`HttpUrl`    AS `DeviceIP`,
          `site`.`DomainID`   AS `DomainID`
        FROM (`ydjw`.`mositehttp` `http` LEFT JOIN `ydjw`.`mowebsite` `site` ON ((`site`.`MOID` = `http`.`ParentMOID`)))
  UNION SELECT
          `reader`.`MOID`        AS `MOID`,
          `reader`.`ReaderLabel` AS `MOName`,
          NULL                   AS `AlarmLevel`,
          `reader`.`MOClassID`   AS `MOClassID`,
          `reader`.`IPAddress`   AS `DeviceIP`,
          `zo`.`DomainID`        AS `DomainID`
        FROM
          (`ydjw`.`moreader` `reader` LEFT JOIN `ydjw`.`mozonemanager` `zo` ON ((`zo`.`MOID` = `reader`.`ParentMOID`)));
