CREATE VIEW platformrestypeview AS
  SELECT
    `ydjw`.`resprefixgatekeeper`.`CiId`            AS `ciId`,
    `ydjw`.`resprefixgatekeeper`.`COL_deviceType`  AS `type`,
    `ydjw`.`resprefixgatekeeper`.`COL_channeltype` AS `cType`
  FROM `ydjw`.`resprefixgatekeeper`
  UNION SELECT
          `ydjw`.`resprefixfirewall`.`CiId`            AS `ciId`,
          `ydjw`.`resprefixfirewall`.`COL_deviceType`  AS `type`,
          `ydjw`.`resprefixfirewall`.`COL_channeltype` AS `cType`
        FROM `ydjw`.`resprefixfirewall`
  UNION SELECT
          `ydjw`.`resprefixswitch`.`CiId`            AS `ciId`,
          `ydjw`.`resprefixswitch`.`COL_deviceType`  AS `type`,
          `ydjw`.`resprefixswitch`.`COL_channeltype` AS `cType`
        FROM `ydjw`.`resprefixswitch`
  UNION SELECT
          `ydjw`.`resprefixrouter`.`CiId`            AS `ciId`,
          `ydjw`.`resprefixrouter`.`COL_deviceType`  AS `type`,
          `ydjw`.`resprefixrouter`.`COL_channeltype` AS `cType`
        FROM `ydjw`.`resprefixrouter`
  UNION SELECT
          `ydjw`.`resprefixserver`.`CiId`            AS `ciId`,
          `ydjw`.`resprefixserver`.`COL_deviceType`  AS `type`,
          `ydjw`.`resprefixserver`.`COL_channeltype` AS `cType`
        FROM `ydjw`.`resprefixserver`
  UNION SELECT
          `ydjw`.`resprefixvpngateway`.`CiId`            AS `ciId`,
          `ydjw`.`resprefixvpngateway`.`COL_deviceType`  AS `type`,
          `ydjw`.`resprefixvpngateway`.`COL_channeltype` AS `cType`
        FROM `ydjw`.`resprefixvpngateway`
  UNION SELECT
          `ydjw`.`resprefixproxygateway`.`CiId`            AS `ciId`,
          `ydjw`.`resprefixproxygateway`.`COL_deviceType`  AS `type`,
          `ydjw`.`resprefixproxygateway`.`COL_channeltype` AS `cType`
        FROM `ydjw`.`resprefixproxygateway`
  UNION SELECT
          `ydjw`.`resprefixdeviceprobe`.`CiId`            AS `ciId`,
          `ydjw`.`resprefixdeviceprobe`.`COL_devicetype`  AS `type`,
          `ydjw`.`resprefixdeviceprobe`.`COL_channeltype` AS `cType`
        FROM `ydjw`.`resprefixdeviceprobe`
  UNION SELECT
          `ydjw`.`resprefixdevicebalancing`.`CiId`            AS `ciId`,
          `ydjw`.`resprefixdevicebalancing`.`COL_devicetype`  AS `type`,
          `ydjw`.`resprefixdevicebalancing`.`COL_channeltype` AS `cType`
        FROM `ydjw`.`resprefixdevicebalancing`
  UNION SELECT
          `ydjw`.`resprefixmobileappproxy`.`CiId`            AS `ciId`,
          `ydjw`.`resprefixmobileappproxy`.`COL_devicetype`  AS `type`,
          `ydjw`.`resprefixmobileappproxy`.`COL_channeltype` AS `cType`
        FROM `ydjw`.`resprefixmobileappproxy`
  UNION SELECT
          `ydjw`.`resprefixmobileappmanger`.`CiId`            AS `ciId`,
          `ydjw`.`resprefixmobileappmanger`.`COL_devicetype`  AS `type`,
          `ydjw`.`resprefixmobileappmanger`.`COL_channeltype` AS `cType`
        FROM `ydjw`.`resprefixmobileappmanger`;
