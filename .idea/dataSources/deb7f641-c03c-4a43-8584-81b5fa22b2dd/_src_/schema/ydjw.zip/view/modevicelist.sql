CREATE VIEW modevicelist AS
  SELECT
    `ydjw`.`resprefixdevicebalancing`.`COL_channeltype`   AS `channelType`,
    `ydjw`.`resprefixdevicebalancing`.`COL_deviceip`      AS `ip`,
    `ydjw`.`resprefixdevicebalancing`.`COL_devicepurpose` AS `purpose`,
    `ydjw`.`resprefixdevicebalancing`.`CiId`              AS `ciId`
  FROM `ydjw`.`resprefixdevicebalancing`
  UNION SELECT
          `a`.`COL_channelType`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixmidrangecomputer` `a` LEFT JOIN `ydjw`.`resprefixcomputer` `b`
            ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channeltype`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixserver` `a` LEFT JOIN `ydjw`.`resprefixcomputer` `b` ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channelType`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixworkstation` `a` LEFT JOIN `ydjw`.`resprefixcomputer` `b` ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channelType`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM
          (`ydjw`.`resprefixvirtualhosting` `a` LEFT JOIN `ydjw`.`resprefixcomputer` `b` ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channeltype`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `a`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixrouter` `a` LEFT JOIN `ydjw`.`resprefixnetworkdevice` `b` ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channeltype`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `a`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixswitch` `a` LEFT JOIN `ydjw`.`resprefixnetworkdevice` `b` ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channelType`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `a`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixhub` `a` LEFT JOIN `ydjw`.`resprefixnetworkdevice` `b` ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channeltype`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixvpngateway` `a` LEFT JOIN `ydjw`.`resprefixsafetyequipment` `b`
            ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channeltype`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixproxygateway` `a` LEFT JOIN `ydjw`.`resprefixsafetyequipment` `b`
            ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channeltype`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixdeviceprobe` `a` LEFT JOIN `ydjw`.`resprefixsafetyequipment` `b`
            ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channeltype`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixfirewall` `a` LEFT JOIN `ydjw`.`resprefixsafetyequipment` `b`
            ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channelType`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixintrusiondetection` `a` LEFT JOIN `ydjw`.`resprefixsafetyequipment` `b`
            ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channeltype`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixgatekeeper` `a` LEFT JOIN `ydjw`.`resprefixsafetyequipment` `b`
            ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channelType`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixinvadedefense` `a` LEFT JOIN `ydjw`.`resprefixsafetyequipment` `b`
            ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channeltype`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixmobileappproxy` `a` LEFT JOIN `ydjw`.`resprefixsafetyequipment` `b`
            ON ((`a`.`CiId` = `b`.`CiId`)))
  UNION SELECT
          `a`.`COL_channeltype`   AS `COL_channelType`,
          `b`.`COL_deviceip`      AS `COL_deviceip`,
          `b`.`COL_devicepurpose` AS `COL_devicepurpose`,
          `a`.`CiId`              AS `CiId`
        FROM (`ydjw`.`resprefixmobileappmanger` `a` LEFT JOIN `ydjw`.`resprefixsafetyequipment` `b`
            ON ((`a`.`CiId` = `b`.`CiId`)));
