CREATE VIEW v_networkchanneldevice AS
  SELECT
    `ydjw`.`modevice`.`ResID`   AS `CiId`,
    ''                          AS `ApplicationType`,
    ''                          AS `Area`,
    ''                          AS `NetWork`,
    `ydjw`.`modevice`.`MOID`    AS `MOID`,
    `ydjw`.`modevice`.`MOName`  AS `MOName`,
    `ydjw`.`modevice`.`MOAlias` AS `MOAlias`
  FROM `ydjw`.`modevice`
  WHERE (`ydjw`.`modevice`.`ResID` IS NOT NULL);
